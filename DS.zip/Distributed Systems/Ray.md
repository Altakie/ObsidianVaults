- Uses Distributed Futures
# Futures
- Lazily evaluated


- Transparent recovery of idempotent futures
	- 

# Recovery
- Lineage
	- Every future has a list of invocations that created it
	- This list can be used to recreate that future
- Lineage Reconstruction
	- Re-execute futures and their descendants
	- Works because futures are idempotent

# Sharded Table

# Fate Sharing
- If owner crashes, I also crash
- Loss of owned object leads to re-execution