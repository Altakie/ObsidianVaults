- Byzantine Failure Model
	- Failed server can do whatever
	- Outnumber bad guys every time you want to make a decision
		- Voting
	- Worst case
		- All bag servers are controlled by single attacker

- View Change
	- Needs $2f+1$ replicas to send a prepare to start commit phase
	- Then needs $2f + 1$ commits
	- Only executes after commit phase
	- View change execution:
		1. New primary sends out $2f+1$ prepares for all recent operations
		2. New primary waits for $2f+1$ View Change requests
		3. Fixes the log based on the prepare requests
		4. Now has evidence for View Change
		5. Starts commit phase
		6. Waits for $2f+1$ commits
	- Allows for up to $f$ replicas to be bad, but need $f+1$ replicas to be good
	- Since majority of replicas must be good, there is at least one good replica in common between each majority
	- Communication is bottleneck in this system
- Main takeaways
	- View Change
		- Why is second phase needed?
	- Normal Case
		- What is the protocol?
	- Do not need to know optimizations